def hello ():
    print("Hello World!!")